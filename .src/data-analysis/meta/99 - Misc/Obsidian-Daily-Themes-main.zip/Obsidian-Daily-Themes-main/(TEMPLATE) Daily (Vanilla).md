---
date: {{date}}T{{time}}
tags: [Daily]
cssclasses: [daily, {{date:dddd}}]
---
# DAILY NOTE
### *{{date:dddd, MMMM Do, YYYY}}*

## Journal
...

## Ongoing Tasks
- [ ] Task 1
- [ ] Task 2
- [ ] Task 3