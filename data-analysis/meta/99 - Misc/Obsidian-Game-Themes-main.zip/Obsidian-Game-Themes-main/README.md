# Obsidian-Game-Themes v1.0.2
## A Series of Video Game Theme CSS Snippets for Obsidian.

This is a collection of a few of my video game themed snippets for Obsidian. As of writing, there's just a Minecraft and Old School RuneScape theme. Over time I'll likely add more themes from other games as well as clean up the CSS code, creating a consistent template to work off of.

### Theme Dependencies
Minecraft:
- The [Minecraftia](https://www.dafont.com/minecraftia.font) or [Minecraft](https://www.dafont.com/minecraft.font) fonts *(Body)*
- The [Minercraftory](https://www.dafont.com/minercraftory.font) or [Minecrafter](https://www.dafont.com/minecrafter.font) fonts *(H1)*

RuneScape:
- The [RuneScape UF](https://www.dafont.com/runescape-uf.font) font *(Body)*
